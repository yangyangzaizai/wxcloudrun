# MYadminV3
Myadmin-V3是一个基于ThinkPHP6+Bootstrap的免费开源，快速简单，面向对象的应用研发架构，是为了快速研发应用而诞生。在保持出色的性能和新颖设计思想同时，也注重易用性。遵循Apache2开源许可协议发布，您可以免费使用Myadmin将研发的产品发布或销售，但不能未经授权抹除产品标志再次用于开源。

> 运行环境要求PHP7.4+，兼容PHP8.1## 安装

**强烈推荐gitee**
~~~
git clone https://gitee.com/dream-kc/myadmin-v3.git
~~~

运行命令
~~~
composer install
~~~
配置数据库信息

~~~
config/database.php
~~~

导入数据库

~~~
根目录/sql.sql
~~~

默认账户密码：`admin`  `123456`

## 特别鸣谢


笔下光年（http://www.bixiaguangnian.com/）

Bootstrap

thinkphp

