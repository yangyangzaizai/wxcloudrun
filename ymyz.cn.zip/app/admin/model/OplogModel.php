<?php

namespace app\admin\model;

use think\Model;

class OplogModel extends Model
{
// 模型名
    protected $name = 'oplog';
}