<?php

namespace app\admin\model;

use think\Model;

class Fileupdate extends Model
{

}