<?php

namespace app\admin\model;

use think\Model;

class Classify extends Model
{

}