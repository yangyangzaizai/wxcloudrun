<?php

namespace app\admin\model;

use think\Model;

class AuthRule extends Model
{

}