<?php

namespace app\admin\model;

use think\Model;

class Camilo extends Model
{

}