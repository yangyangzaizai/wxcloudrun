<?php /*a:1:{s:59:"D:\phpstudy_pro\WWW\ymyz.cn\app\admin\view\index\index.html";i:1644970833;}*/ ?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="keywords" content="<?php echo basicConfiguration('keywords'); ?>">
    <meta name="description" content="<?php echo basicConfiguration('description'); ?>">
    <meta name="author" content="yinq">
    <title><?php echo basicConfiguration('title'); ?> - MYADMIN后台管理系统</title>
    <link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <link rel="stylesheet" type="text/css" href="/static/admin/css/materialdesignicons.min.css">
    <link rel="stylesheet" type="text/css" href="/static/admin/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/static/admin/js/bootstrap-multitabs/multitabs.min.css">
    <link rel="stylesheet" type="text/css" href="/static/admin/css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="/static/admin/css/style.min.css">
    <link rel="stylesheet" type="text/css" href="/static/admin/css/diy.css">
    <link rel="stylesheet" href="https://at.alicdn.com/t/font_1764854_gqjwxrn976p.css">
    <link rel="stylesheet" href="/static/admin/css/font-awesome.min.css">
    <link href="/static/admin/js/jquery-confirm/jquery-confirm.min.css" rel="stylesheet">
</head>
<style>
    .gotop {
        position: fixed;
        bottom: 0;
        right: 0;
        margin: 30px;
        z-index: 999;
    }
    .ceo-animation-slide-bottom-small {
        animation-name: ceo-fade-bottom-small;
    }
    [class*='ceo-animation-'] {
        animation-duration: 0.5s;
        animation-timing-function: ease-out;
        animation-fill-mode: both;
    }
    .gotop-box {
        position: relative;
    }
    .ceo_follow_img {
        margin-bottom: 10px;
    }
    .ceo-background-default {
        background-color: #fff;
        width: 200px;
    }
    .b-a {
        border: 1px solid var(--border-color) !important;
    }
</style>
<body>
<div class="lyear-layout-web">
    <div class="lyear-layout-container">
        <!--左侧导航-->
        <aside class="lyear-layout-sidebar">

            <!-- logo -->
            <div id="logo" class="sidebar-header">
                <a href="index.html"><img src="/static/admin/images/logo-sidebar.png" title="LightYear" alt="LightYear" /></a>
            </div>
            <div class="lyear-layout-sidebar-info lyear-scroll">

                <nav class="sidebar-main">
                    <ul class="nav-drawer">
                        <li class="nav-item active"> <a class="multitabs" href="/admin/index/main"><i class="mdi mdi-home"></i> <span>后台首页</span></a> </li>
                        <?php if(is_array($sidenav) || $sidenav instanceof \think\Collection || $sidenav instanceof \think\Paginator): if( count($sidenav)==0 ) : echo "" ;else: foreach($sidenav as $key=>$v): if(isset($v['children'])): ?>
                        <li class="nav-item nav-item-has-subnav">
                            <a href="javascript:void(0)"><i class="<?php echo htmlentities($v['icon']); ?>"></i> <span><?php echo htmlentities($v['title']); ?></span></a>
                            <ul class="nav nav-subnav">
                                <?php if(is_array($v['children']) || $v['children'] instanceof \think\Collection || $v['children'] instanceof \think\Paginator): if( count($v['children'])==0 ) : echo "" ;else: foreach($v['children'] as $key=>$sub1): ?>
                                <li> <a class="multitabs" href="/<?php echo htmlentities($sub1['name']); ?>"><?php echo htmlentities($sub1['title']); ?></a> </li>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                            </ul>
                        </li>
                        <?php else: ?>
                        <li class="nav-item active"> <a class="multitabs" href="/<?php echo htmlentities($v['name']); ?>"><i class="mdi mdi-home"></i> <span><?php echo htmlentities($v['title']); ?></span></a> </li>
                        <?php endif; ?>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </ul>
                </nav>

                <div class="sidebar-footer">
                    <p class="copyright">Copyright &copy; 2022. <a target="_blank" href="https://gitee.com/dream-kc/myadmin-v3">梦亚科创</a> All rights reserved.</p>
                </div>
            </div>

        </aside>
        <!--End 左侧导航-->

        <!--头部信息-->
        <header class="lyear-layout-header">

            <nav class="navbar">

                <div class="navbar-left">
                    <div class="lyear-aside-toggler">
                        <span class="lyear-toggler-bar"></span>
                        <span class="lyear-toggler-bar"></span>
                        <span class="lyear-toggler-bar"></span>
                    </div>
                </div>

                <ul class="navbar-right d-flex align-items-center">
                    <li class="dropdown dropdown-notice">
            <span data-toggle="dropdown" class="icon-item">
              <i class="mdi mdi-bell-outline"></i>
              <span class="badge badge-danger"><?php echo count($gxrz); ?></span>
            </span>
                        <div class="dropdown-menu dropdown-menu-right">
                            <div class="lyear-notifications">

                                <div class="lyear-notifications-title clearfix"  data-stopPropagation="true"><a href="#!" onclick="lists()" class="float-right">查看全部</a>你有 <?php echo count($gxrz); ?> 条未读消息</div>
                                <div class="lyear-notifications-info lyear-scroll">
                                    <?php if(is_array($gxrz) || $gxrz instanceof \think\Collection || $gxrz instanceof \think\Paginator): if( count($gxrz)==0 ) : echo "" ;else: foreach($gxrz as $key=>$vs): ?>
                                    <a href="#!" onclick="xqs(<?php echo htmlentities($vs['id']); ?>)" class="dropdown-item" title="<?php echo htmlentities($vs['title']); ?>"><?php echo htmlentities($vs['title']); ?></a>
                                    <?php endforeach; endif; else: echo "" ;endif; ?>
<!--                                    <a href="#!" class="dropdown-item" title="GNOME 用户体验团队将为 GNOME Shell 提供更多改进">GNOME 用户体验团队将为 GNOME Shell 提供更多改进</a>-->
<!--                                    <a href="#!" class="dropdown-item" title="Linux On iPhone 即将面世，支持 iOS 的双启动">Linux On iPhone 即将面世，支持 iOS 的双启动</a>-->
<!--                                    <a href="#!" class="dropdown-item" title="GitHub 私有仓库完全免费面向团队提供">GitHub 私有仓库完全免费面向团队提供</a>-->
<!--                                    <a href="#!" class="dropdown-item" title="Wasmtime 为 WebAssembly 增加 Go 语言绑定">Wasmtime 为 WebAssembly 增加 Go 语言绑定</a>-->
<!--                                    <a href="#!" class="dropdown-item" title="红帽借“订阅”成开源一哥，首创者 Cormier 升任总裁">红帽借“订阅”成开源一哥，首创者 Cormier 升任总裁</a>-->
<!--                                    <a href="#!" class="dropdown-item" title="Zend 宣布推出两项 PHP 新产品">Zend 宣布推出两项 PHP 新产品</a>-->
                                </div>

                            </div>
                        </div>
                    </li>
                    <!--切换主题配色-->
                    <li class="dropdown dropdown-skin">
                        <span data-toggle="dropdown" class="icon-item"><i class="mdi mdi-palette"></i></span>
                        <ul class="dropdown-menu dropdown-menu-right" data-stopPropagation="true">
                            <li class="drop-title"><p>LOGO</p></li>
                            <li class="drop-skin-li clearfix">
                <span class="inverse">
                  <input type="radio" name="logo_bg" value="default" id="logo_bg_1" checked>
                  <label for="logo_bg_1"></label>
                </span>
                                <span>
                  <input type="radio" name="logo_bg" value="color_2" id="logo_bg_2">
                  <label for="logo_bg_2"></label>
                </span>
                                <span>
                  <input type="radio" name="logo_bg" value="color_3" id="logo_bg_3">
                  <label for="logo_bg_3"></label>
                </span>
                                <span>
                  <input type="radio" name="logo_bg" value="color_4" id="logo_bg_4">
                  <label for="logo_bg_4"></label>
                </span>
                                <span>
                  <input type="radio" name="logo_bg" value="color_5" id="logo_bg_5">
                  <label for="logo_bg_5"></label>
                </span>
                                <span>
                  <input type="radio" name="logo_bg" value="color_6" id="logo_bg_6">
                  <label for="logo_bg_6"></label>
                </span>
                                <span>
                  <input type="radio" name="logo_bg" value="color_7" id="logo_bg_7">
                  <label for="logo_bg_7"></label>
                </span>
                                <span>
                  <input type="radio" name="logo_bg" value="color_8" id="logo_bg_8">
                  <label for="logo_bg_8"></label>
                </span>
                            </li>
                            <li class="drop-title"><p>头部</p></li>
                            <li class="drop-skin-li clearfix">
                <span class="inverse">
                  <input type="radio" name="header_bg" value="default" id="header_bg_1" checked>
                  <label for="header_bg_1"></label>
                </span>
                                <span>
                  <input type="radio" name="header_bg" value="color_2" id="header_bg_2">
                  <label for="header_bg_2"></label>
                </span>
                                <span>
                  <input type="radio" name="header_bg" value="color_3" id="header_bg_3">
                  <label for="header_bg_3"></label>
                </span>
                                <span>
                  <input type="radio" name="header_bg" value="color_4" id="header_bg_4">
                  <label for="header_bg_4"></label>
                </span>
                                <span>
                  <input type="radio" name="header_bg" value="color_5" id="header_bg_5">
                  <label for="header_bg_5"></label>
                </span>
                                <span>
                  <input type="radio" name="header_bg" value="color_6" id="header_bg_6">
                  <label for="header_bg_6"></label>
                </span>
                                <span>
                  <input type="radio" name="header_bg" value="color_7" id="header_bg_7">
                  <label for="header_bg_7"></label>
                </span>
                                <span>
                  <input type="radio" name="header_bg" value="color_8" id="header_bg_8">
                  <label for="header_bg_8"></label>
                </span>
                            </li>
                            <li class="drop-title"><p>侧边栏</p></li>
                            <li class="drop-skin-li clearfix">
                <span class="inverse">
                  <input type="radio" name="sidebar_bg" value="default" id="sidebar_bg_1" checked>
                  <label for="sidebar_bg_1"></label>
                </span>
                                <span>
                  <input type="radio" name="sidebar_bg" value="color_2" id="sidebar_bg_2">
                  <label for="sidebar_bg_2"></label>
                </span>
                                <span>
                  <input type="radio" name="sidebar_bg" value="color_3" id="sidebar_bg_3">
                  <label for="sidebar_bg_3"></label>
                </span>
                                <span>
                  <input type="radio" name="sidebar_bg" value="color_4" id="sidebar_bg_4">
                  <label for="sidebar_bg_4"></label>
                </span>
                                <span>
                  <input type="radio" name="sidebar_bg" value="color_5" id="sidebar_bg_5">
                  <label for="sidebar_bg_5"></label>
                </span>
                                <span>
                  <input type="radio" name="sidebar_bg" value="color_6" id="sidebar_bg_6">
                  <label for="sidebar_bg_6"></label>
                </span>
                                <span>
                  <input type="radio" name="sidebar_bg" value="color_7" id="sidebar_bg_7">
                  <label for="sidebar_bg_7"></label>
                </span>
                                <span>
                  <input type="radio" name="sidebar_bg" value="color_8" id="sidebar_bg_8">
                  <label for="sidebar_bg_8"></label>
                </span>
                            </li>
                        </ul>
                    </li>
                    <!--切换主题配色-->
                    <li class="dropdown dropdown-profile">
                        <a href="javascript:void(0)" data-toggle="dropdown" class="dropdown-toggle">
<!--                            <img class="img-avatar img-avatar-48 m-r-10" src="/static/admin/images/users/avatar.jpg" alt="<?php echo htmlentities($admininfo['username']); ?>" />-->
                            <span><?php echo htmlentities($admininfo['username']); ?></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-right">
                            <li>
                                <a class="multitabs dropdown-item" data-url="/admin/tpl/password" href="javascript:void(0)"><i class="mdi mdi-lock-outline"></i> 修改密码</a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="javascript:void(0)" onclick="cache()"><i class="mdi mdi-delete"></i> 清空缓存</a>
                            </li>
                            <li class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item" href="javascript:void(0)" onclick="logout()"><i class="mdi mdi-logout-variant"></i> 退出登录</a>
                            </li>
                        </ul>
                    </li>
                </ul>

            </nav>

        </header>
        <!--End 头部信息-->

        <!--页面主要内容-->
        <main class="lyear-layout-content">

            <div id="iframe-content"></div>

        </main>
        <!--End 页面主要内容-->
    </div>
</div>

<div class="gotop ceo-animation-slide-bottom-small">
    <div class="gotop-box">

        <div class="gotop-boxan">

            <div class="gotop-item ceo-background-default gotop-service">
                <i class="iconfont icon-service-fill"></i>
                <div class="gotop-service-box ceo-background-default b-a">
                    <span class="you"></span>
                    <div class="tops">
                        <img src="/static/admin/images/ceo-gotop-qq.png">
                        <a href="https://qm.qq.com/cgi-bin/qm/qr?k=h7VQVamsSC3J1QfgXKyXIWnsB0NjqLLj&jump_from=webapi" class="topsqq">点击联系客服</a>
                        <p>在线时间：8:00-16:00</p>
                    </div>
                    <div class="btms">
                        <h5>客服QQ</h5>
                        <p>2559584938</p>
                        <h4>客服邮箱</h4>
                        <span>2559584938@qq.com</span>
                    </div>
                </div>
            </div>

            <div class="gotop-item ceo-background-default gotop-wx">
                <i class="iconfont icon-qrcode"></i>
                <div class="gotop-wx-box ceo-background-default b-a">
                    <span class="you"></span>
                    <div class="tops">
                        <p>扫描二维码</p>
                        <p>进入QQ交流群</p>
                        <img src="/static/admin/images/ceo-ma.png">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript" src="/static/admin/js/jquery.min.js"></script>
<script type="text/javascript" src="/static/admin/js/popper.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/static/admin/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap-multitabs/multitabs.min.js"></script>
<script type="text/javascript" src="/static/admin/js/jquery.cookie.min.js"></script>
<script type="text/javascript" src="/static/admin/js/index.min.js"></script>
<script type="text/javascript" src="/static/admin/js/jquery-confirm/jquery-confirm.min.js"></script>
<script>
    function logout() {
        $.ajax({
            url: "/admin/login/logout",
            success: function (e) {
                $.alert({
                    title: '成功',
                    icon: 'mdi mdi-alert',
                    type: 'blue',
                    content: e.msg,
                    buttons: {
                        okay: {
                            text: '确认',
                            btnClass: 'btn-blue',
                            action: function() {
                                location.href = "<?php echo url('admin/login/index'); ?>"
                            }
                        }
                    }
                });
            }
        })
    }
    function cache() {
        $.ajax({
            url:"/admin/tpl/clear",
            success:function(res){
                if(res.code == 1){
                    $.alert({
                        title: '成功',
                        icon: 'mdi mdi-alert',
                        type: 'blue',
                        content: res.msg,
                        buttons: {
                            okay: {
                                text: '确认',
                                btnClass: 'btn-blue',
                                action: function() {

                                }
                            }
                        }
                    });
                } else {
                    $.alert({
                        title: '提示',
                        icon: 'mdi mdi-alert',
                        type: 'red',
                        content: res.msg,
                        buttons: {
                            okay: {
                                text: '确认',
                                btnClass: 'btn-blue',
                                action: function() {

                                }
                            }
                        }
                    });
                }
            }
        })
    };
    function xqs(id) {
        parent.$(parent.document).data('multitabs').create({
            iframe : true,                                // 指定为iframe模式，当值为false的时候，为智能模式，自动判断（内网用ajax，外网用iframe）。缺省为false。
            title : '内容详情',                     // 标题（可选），没有则显示网址
            url : '/admin/index/xiangq?id=' + id                    // 链接（必须），如为外链，强制为info页
        }, true);
    }
    function lists() {
        parent.$(parent.document).data('multitabs').create({
            iframe : true,                                // 指定为iframe模式，当值为false的时候，为智能模式，自动判断（内网用ajax，外网用iframe）。缺省为false。
            title : '所有内容',                     // 标题（可选），没有则显示网址
            url : '/admin/index/lists'                    // 链接（必须），如为外链，强制为info页
        }, true);
    }
</script>
</body>
</html>